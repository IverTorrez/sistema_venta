SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `tb_administrador`;

CREATE TABLE `tb_administrador` (
  `id_administrador` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_administrador` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `apellido_administrador` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `telefono_administrador` int(11) DEFAULT NULL,
  `user_admin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `password_admin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `estado_admin` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `observacion_admin` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  PRIMARY KEY (`id_administrador`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tb_administrador` VALUES (1,"AMINISTRADOR","administrador",67676787,"admin123","admin123","Activo","Es el administrador del sistema");


DROP TABLE IF EXISTS `tb_almacen`;

CREATE TABLE `tb_almacen` (
  `id_almacen` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_almacen` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `usuario_alta` int(11) DEFAULT NULL,
  `fecha_alta` datetime DEFAULT NULL,
  `estado` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usuario_baja` int(11) DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  PRIMARY KEY (`id_almacen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_categoria`;

CREATE TABLE `tb_categoria` (
  `id_categoria` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_categoria` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `estado_cat` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_categoria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_cierre_caja`;

CREATE TABLE `tb_cierre_caja` (
  `id_cierre_caja` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_cierre` datetime DEFAULT NULL,
  `monto_venta_cierre` decimal(30,2) DEFAULT NULL,
  `monto_caja` decimal(30,2) DEFAULT NULL,
  `monto_sobrante` decimal(30,2) DEFAULT NULL,
  `cantidad_ventas` int(11) DEFAULT NULL,
  `codigos_ventas` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  `id_empleado` int(11) DEFAULT NULL,
  `estado` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_usuario_alta` int(11) DEFAULT NULL,
  `fecha_alta` datetime DEFAULT NULL,
  `id_usuario_baja` int(11) DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  `cantidad_productos` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_cierre_caja`),
  KEY `id_empleado` (`id_empleado`),
  CONSTRAINT `tb_cierre_caja_ibfk_1` FOREIGN KEY (`id_empleado`) REFERENCES `tb_empleado` (`id_empleado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_cierre_caja_venta`;

CREATE TABLE `tb_cierre_caja_venta` (
  `id_cierre_caja_venta` int(11) NOT NULL AUTO_INCREMENT,
  `id_cierre_caja` int(11) DEFAULT NULL,
  `id_venta` int(11) DEFAULT NULL,
  `estado` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_empleado` int(11) DEFAULT NULL,
  `id_admin` int(11) DEFAULT NULL,
  `fecha_accion` date DEFAULT NULL,
  `fecha_alta` datetime DEFAULT NULL,
  `id_admin_baja` int(11) DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  PRIMARY KEY (`id_cierre_caja_venta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_cliente`;

CREATE TABLE `tb_cliente` (
  `id_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_cliente` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `apellido_cliente` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `telefono_cliente` int(11) DEFAULT NULL,
  `estado_cliente` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `observacion` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_compra`;

CREATE TABLE `tb_compra` (
  `id_compra` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_compra` datetime DEFAULT NULL,
  `monto_compra` decimal(30,2) DEFAULT NULL,
  `compra_facturada` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `costo_factura` decimal(30,2) DEFAULT NULL,
  `usuario_alta` int(11) DEFAULT NULL,
  `id_proveedor` int(11) DEFAULT NULL,
  `estado` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_reg` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usuario_baja` int(11) DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  PRIMARY KEY (`id_compra`),
  KEY `id_proveedor` (`id_proveedor`),
  CONSTRAINT `tb_compra_ibfk_1` FOREIGN KEY (`id_proveedor`) REFERENCES `tb_proveedor` (`id_proveedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_compra_producto`;

CREATE TABLE `tb_compra_producto` (
  `id_compra_producto` int(11) NOT NULL AUTO_INCREMENT,
  `subtotal_compra` decimal(30,2) DEFAULT NULL,
  `cantidad_compra` int(11) DEFAULT NULL,
  `id_compra` int(11) DEFAULT NULL,
  `id_producto` int(11) DEFAULT NULL,
  `precio_unit_compra` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `precio_unit_compraFacturado` decimal(30,2) DEFAULT NULL,
  `precio_venta_prod` decimal(30,2) DEFAULT NULL,
  `precio_venta_prod_Fact` decimal(30,2) DEFAULT NULL,
  `stock_actual` int(11) DEFAULT NULL,
  `precio_tope` decimal(30,2) DEFAULT NULL,
  `estado` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_compra_producto`),
  KEY `id_compra` (`id_compra`),
  KEY `id_producto` (`id_producto`),
  CONSTRAINT `tb_compra_producto_ibfk_1` FOREIGN KEY (`id_compra`) REFERENCES `tb_compra` (`id_compra`),
  CONSTRAINT `tb_compra_producto_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `tb_producto` (`id_producto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_empleado`;

CREATE TABLE `tb_empleado` (
  `id_empleado` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_empleado` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `apellido_empleado` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `telefono_empleado` int(11) DEFAULT NULL,
  `user_name_emp` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `password_emp` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `estado_empleado` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacion_emp` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  `permiso_especial` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_empleado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_marca`;

CREATE TABLE `tb_marca` (
  `id_marca` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_marca` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `estado_marca` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id_marca`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_precio_factura`;

CREATE TABLE `tb_precio_factura` (
  `id_precio_factura` int(11) NOT NULL AUTO_INCREMENT,
  `porcentaje_p_nofacturado` int(11) DEFAULT NULL,
  `porcentaje_p_facturado` int(11) DEFAULT NULL,
  `id_administrador` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_precio_factura`),
  KEY `id_administrador` (`id_administrador`),
  CONSTRAINT `tb_precio_factura_ibfk_1` FOREIGN KEY (`id_administrador`) REFERENCES `tb_administrador` (`id_administrador`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_producto`;

CREATE TABLE `tb_producto` (
  `id_producto` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_producto` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `codigo_producto` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `descripcion` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `stok_facturado` int(11) DEFAULT NULL,
  `stock_simple` int(11) DEFAULT NULL,
  `estado_producto` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_marca` int(11) DEFAULT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  `tipo_reg` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usuario_alta` int(11) DEFAULT NULL,
  `fecha_alta` datetime DEFAULT NULL,
  `usuario_baja` int(11) DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  `fecha_modificacion` datetime DEFAULT NULL,
  `id_almacen` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_producto`),
  KEY `id_marca` (`id_marca`),
  KEY `id_categoria` (`id_categoria`),
  CONSTRAINT `tb_producto_ibfk_1` FOREIGN KEY (`id_marca`) REFERENCES `tb_marca` (`id_marca`),
  CONSTRAINT `tb_producto_ibfk_2` FOREIGN KEY (`id_categoria`) REFERENCES `tb_categoria` (`id_categoria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_proveedor`;

CREATE TABLE `tb_proveedor` (
  `id_proveedor` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_proveedor` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `apellido_proveedor` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `telefono_proveedor` int(11) DEFAULT NULL,
  `estado_proveedor` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `observacion` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  PRIMARY KEY (`id_proveedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_sucursal`;

CREATE TABLE `tb_sucursal` (
  `id_sucursal` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_suc` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `descripcion_suc` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `contacto` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `estado_suc` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id_sucursal`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_transferencia_stock_envio`;

CREATE TABLE `tb_transferencia_stock_envio` (
  `id_transferencia_envio` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_transferencia_enviada` datetime DEFAULT NULL,
  `cantidad_envio` int(11) DEFAULT NULL,
  `estado` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_compra_producto` int(11) DEFAULT NULL,
  `descripcion_trans_envio` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `id_sucursal_destino` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_transferencia_envio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_transferencia_stock_recibido`;

CREATE TABLE `tb_transferencia_stock_recibido` (
  `id_transferencia_recibido` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_trn_recibido` datetime DEFAULT NULL,
  `id_compra_producto` int(11) DEFAULT NULL,
  `cantidad_recibida` int(11) DEFAULT NULL,
  `estado_recibida` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descripcion_recibido` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `id_sucursal_origen` int(11) DEFAULT NULL,
  `codigo_de_envio` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_transferencia_recibido`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_venta`;

CREATE TABLE `tb_venta` (
  `id_venta` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_venta` datetime DEFAULT NULL,
  `monto_venta` decimal(30,2) DEFAULT NULL,
  `venta_facturada` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `precio_facturaV` decimal(30,2) DEFAULT NULL,
  `tipo_venta` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_empleado` int(11) DEFAULT NULL,
  `estado` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usuario_baja` int(11) DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  PRIMARY KEY (`id_venta`),
  KEY `id_empleado` (`id_empleado`),
  CONSTRAINT `tb_venta_ibfk_1` FOREIGN KEY (`id_empleado`) REFERENCES `tb_empleado` (`id_empleado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_venta_cliente`;

CREATE TABLE `tb_venta_cliente` (
  `id_venta_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) DEFAULT NULL,
  `id_venta` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_venta_cliente`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_venta` (`id_venta`),
  CONSTRAINT `tb_venta_cliente_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `tb_cliente` (`id_cliente`),
  CONSTRAINT `tb_venta_cliente_ibfk_2` FOREIGN KEY (`id_venta`) REFERENCES `tb_venta` (`id_venta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_venta_producto`;

CREATE TABLE `tb_venta_producto` (
  `id_venta_producto` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_prod` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtotal_venta` decimal(30,2) DEFAULT NULL,
  `cantidad_prod` int(11) DEFAULT NULL,
  `ventaP_facturada` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `precio_factura` decimal(30,2) DEFAULT NULL,
  `id_compra_producto` int(11) DEFAULT NULL,
  `id_venta` int(11) DEFAULT NULL,
  `precio_unitario_venta` decimal(30,2) DEFAULT NULL,
  `precio_compra_prod` decimal(30,2) DEFAULT NULL,
  `precio_venta_establecido` decimal(30,2) DEFAULT NULL,
  `estado` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_venta_producto`),
  KEY `id_compra_producto` (`id_compra_producto`),
  KEY `id_venta` (`id_venta`),
  CONSTRAINT `tb_venta_producto_ibfk_1` FOREIGN KEY (`id_compra_producto`) REFERENCES `tb_compra_producto` (`id_compra_producto`),
  CONSTRAINT `tb_venta_producto_ibfk_2` FOREIGN KEY (`id_venta`) REFERENCES `tb_venta` (`id_venta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



SET foreign_key_checks = 1;
